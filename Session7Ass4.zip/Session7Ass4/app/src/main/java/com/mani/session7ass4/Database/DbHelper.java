package com.mani.session7ass4.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by sakshi.banger on 19-09-2016.
 */
public class DbHelper extends SQLiteOpenHelper {
    SQLiteDatabase db;
    public DbHelper(Context context) {
        super(context,"SakshiDb", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table details(_id integer primary key autoincrement,firstname Text,lastname Text)");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public long insertnewuser(String fname,String lname){
        db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();

        cv.put("firstname",fname);
        cv.put("lastname",lname);
        long id=db.insert("details",null,cv);
        return id;

    }
}
