package com.mani.session7ass4.Activities;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.mani.session7ass4.Database.DbHelper;
import com.mani.session7ass4.R;

/**
 * Created by sakshi.banger on 19-09-2016.
 */
public class NewActivity extends Activity implements View.OnClickListener {
    EditText etfirstname,etlastname;
    TextView tvsave;
    SQLiteDatabase db;
    DbHelper dbhelper;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newactivity_main);
        dbhelper=new DbHelper(this);
        etfirstname=(EditText) findViewById(R.id.etfirstname);
        etlastname=(EditText) findViewById(R.id.etlastname);
        tvsave=(TextView)findViewById(R.id.tvsave);
        tvsave.setOnClickListener(this);
        ;
    }

    @Override
    public void onClick(View v) {
String fname=etfirstname.getText().toString();
        String lname=etlastname.getText().toString();
        long id=dbhelper.insertnewuser(fname,lname);
        if(id!=-1){
            Intent i=new Intent(this,MainActivity.class);
            startActivity(i);
        }
        else{
            Toast.makeText(this,"Error Ocurred",Toast.LENGTH_SHORT).show();
        }

    }
}
