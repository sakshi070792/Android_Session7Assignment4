package com.mani.session7ass4.Activities;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import com.mani.session7ass4.Database.DbHelper;
import com.mani.session7ass4.R;

/**
 * Created by sakshi.banger on 19-09-2016.
 */
public class Showuser extends Activity {
    ListView lvusers;
    SQLiteDatabase db;
    DbHelper dbhelper;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.showactivity_main);
        dbhelper=new DbHelper(this);
        db=dbhelper.getWritableDatabase();
        Cursor mcursor=db.rawQuery("select * from details",null);


        lvusers=(ListView) findViewById(R.id.lvusers);
        UserAdapter useradapter=new UserAdapter(this,mcursor);
        lvusers.setAdapter(useradapter);

    }

}
