package com.mani.session7ass4.Activities;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CursorAdapter;
import android.widget.TextView;

import com.mani.session7ass4.Database.DbHelper;
import com.mani.session7ass4.R;

/**
 * Created by sakshi.banger on 19-09-2016.
 */
public class UserAdapter extends CursorAdapter {


    public UserAdapter(Context context, Cursor c) {
        super(context, c);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View retview=inflater.inflate(R.layout.user_row,parent,false);

        return retview;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        TextView tvid=(TextView)view.findViewById(R.id.tvid);
        tvid.setText("ID:"+cursor.getLong(cursor.getColumnIndex("_id"))
        );
        TextView tvfname=(TextView)view.findViewById(R.id.tvfname);
tvfname.setText("First Name:"+cursor.getString(cursor.getColumnIndex(cursor.getColumnName(1))));
        TextView tvlname=(TextView)view.findViewById(R.id.tvlname);
        tvlname.setText("Last Name:"+cursor.getString(cursor.getColumnIndex(cursor.getColumnName(2))));
    }
}
